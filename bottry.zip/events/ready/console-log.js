module.exports = (client) => {
  console.log(`[API] Logged in as ${client.user.tag} is ready`);
};