module.exports = (interaction, commandObject) => {
  if (commandObject.devOnly) {
    if (interaction.member.id !== process.env.OWNER_ID) {
      interaction.reply('This command is only available to the bot owner.');
      return true;
    }
  }
};